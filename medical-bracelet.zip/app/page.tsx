"use client"

import Component from "../alora-interface"

export default function Page() {
  return <Component />
}
